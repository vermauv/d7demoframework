<?php

namespace Drupal\xautoload\ClassLoader;

class CacheNotSupportedException extends \Exception {}