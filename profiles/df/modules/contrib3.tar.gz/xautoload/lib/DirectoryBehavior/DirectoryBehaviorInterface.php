<?php


namespace Drupal\xautoload\DirectoryBehavior;

interface DirectoryBehaviorInterface {


} 