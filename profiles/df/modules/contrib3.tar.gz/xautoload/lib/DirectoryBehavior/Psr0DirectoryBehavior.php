<?php


namespace Drupal\xautoload\DirectoryBehavior;

final class Psr0DirectoryBehavior implements DirectoryBehaviorInterface {
}