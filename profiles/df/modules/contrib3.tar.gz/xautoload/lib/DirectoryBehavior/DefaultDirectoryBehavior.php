<?php


namespace Drupal\xautoload\DirectoryBehavior;

final class DefaultDirectoryBehavior implements DirectoryBehaviorInterface {
}