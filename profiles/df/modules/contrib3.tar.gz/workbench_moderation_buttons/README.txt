-------------------------------------------------------------------------------
workbench_moderation_buttons
Show Workbench Moderation states as buttons instead of a dropdown.
-------------------------------------------------------------------------------
DESCRIPTION:
Show Workbench Moderation states as buttons instead of a dropdown. 
-------------------------------------------------------------------------------
INSTALLATION:

* Put the module in your drupal modules directory and enable it at 
  admin/modules. 
-------------------------------------------------------------------------------
