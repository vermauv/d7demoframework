Please visit the online handbook at http://drupal.org/node/1138274
