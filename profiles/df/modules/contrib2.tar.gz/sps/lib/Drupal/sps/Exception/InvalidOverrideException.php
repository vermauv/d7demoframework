<?php

namespace Drupal\sps\Exception;

class InvalidOverrideException extends SPSException {}
