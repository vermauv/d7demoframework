<?php
namespace Drupal\sps\Test;
class SimpleCacheOverrideController extends \Drupal\sps\Plugins\OverrideController\SimpleCacheOverrideController {
  public $overrides;
}
