<?php

namespace Drupal\sps\Exception;

class InvalidOverrideRowException extends SPSException {}
