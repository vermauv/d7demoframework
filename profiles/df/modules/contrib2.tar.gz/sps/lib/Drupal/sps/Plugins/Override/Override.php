<?php
namespace Drupal\sps\Plugins\Override;

use Drupal\sps\Plugins\OverrideInterface;
use Drupal\sps\Plugins\AbstractPlugin;

abstract class Override extends AbstractPlugin implements OverrideInterface {
}
