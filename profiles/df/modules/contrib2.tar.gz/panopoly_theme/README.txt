Panopoly Theme
==============
Helps with theming and provides many layouts

Key Features
* Includes 31 responsive and cross browser Panel layouts
* Implements "Featured" view mode available for all content types
* Accordian Panels style plugin
* Installation profile specific code to allow install profiles to select a theme
