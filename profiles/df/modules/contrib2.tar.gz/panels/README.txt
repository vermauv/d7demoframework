
Welcome to Panels 3.

A little documentation should go here, but Panels 3 is alsoi a beast - you're
best off checking the online handbook on Drupal.org, or this issue:
http://drupal.org/node/887560. 
