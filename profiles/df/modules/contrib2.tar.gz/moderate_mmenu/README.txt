INTRODUCTION
------------
Moderate mmenu provides an off-screen menu to moderate the current Node.

By default only local tasks (tabs) and the Workbench Moderation block are added
to the menu, but additional blocks can be assigned to the menu via the Blocks
administration page.

REQUIREMENTS
------------
This module requires the following modules:
 * Libraries (https://drupal.org/project/libraries)
 * jQuery Update (https://www.drupal.org/project/jquery_update)

CONFIGURATION
-------------
Beyond assigning blocks to the custom region, there are no extra configuration
options available.
