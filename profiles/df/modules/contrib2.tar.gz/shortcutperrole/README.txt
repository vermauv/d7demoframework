-- SUMMARY --

*Shortcut per Role provide a simple utility for assigning a shortcuts set per 
role


-- REQUIREMENTS --

Core Shortcut module should be enabled


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information


-- CONFIGURATION –

* Go to admin/config/user-interface/shortcut-per-role and assign the shortcut 
set for roles


-- CONTACT --

Current maintainer: 
* webankit - http://drupal.org/user/533078
