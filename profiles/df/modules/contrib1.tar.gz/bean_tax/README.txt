-----BEAN TAX MODULE-----
Bean Tax (short for Bean Taxonomy) is a library
of bean plugins that relate to taxonomy.

--Installation/Configuration--
1. Download and install the Bean module: 
   http://drupal.org/project/bean
2. After turning on Bean Taxonomy, there
   will be new block types available under
   /admin/structure/block_types/list
3. You can configure these block types, add
   fields or manage view modes for display.
4. Create unique block instances under
   /admin/content/blocks

-----

Sponsored by Promet Solutions, Inc.
Visit: http://prometsource.com
