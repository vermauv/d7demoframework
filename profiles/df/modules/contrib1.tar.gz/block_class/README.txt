=====
Block Class
http://drupal.org/project/block_class
-----
Block Class was developed and is maintained by Four Kitchens
<http://fourkitchens.com>.


=====
Installation
-----

1. Enable the module
2. To add a class to a block, simply visit that block's configuration page at
Administration > Structure > Blocks
