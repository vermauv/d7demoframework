# Attention

All CSS files in this folder are copied directly from the navbar module.
The navbar module is used as a model for the unified navigation that is shown whenever navbar is not in use on a site.

If navbar is in use, the navbar module's implementation of these files is used instead.
