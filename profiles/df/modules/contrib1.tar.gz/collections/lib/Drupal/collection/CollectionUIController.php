<?php

namespace Drupal\collection;

class CollectionUIController extends \EntityDefaultUIController {

}
