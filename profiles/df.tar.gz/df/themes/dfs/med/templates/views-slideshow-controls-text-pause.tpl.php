<span id="views_slideshow_controls_text_pause_<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>"></span>
