<?php

namespace Drupal\sps\Exception;

class DoesNotImplementException extends SPSException {}
