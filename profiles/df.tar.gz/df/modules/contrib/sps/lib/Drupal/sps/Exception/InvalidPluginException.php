<?php

namespace Drupal\sps\Exception;

class InvalidPluginException extends SPSException {}
