<?php

namespace Drupal\collection;

class CollectionController extends \EntityAPIControllerExportable {

}
