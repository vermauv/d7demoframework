Classy Panel Styles glob imports all example partials.

Use Case:
A user wants to use the image and background styles only. They should copy the
_utilities.sass and the _background.sass files along with the gemfile and
config.rb. If you already have a config.rb and/or gemfile in your theme, please
compare gem versions to ensure compatibility.
